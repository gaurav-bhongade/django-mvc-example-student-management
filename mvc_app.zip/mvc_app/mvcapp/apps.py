from django.apps import AppConfig


class MvcappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mvcapp'
